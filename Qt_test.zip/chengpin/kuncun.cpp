#include "kuncun.h"
#include "QtDebug"

kuncun::kuncun(const QString& str)
{
    filename=str;
    QFile myfile(str);
    sum=0;
    myfile.open(QIODevice::ReadOnly|QIODevice::Text);
    QTextStream in(&myfile);
    int flag=0;
    while (!in.atEnd()) {
        in>>name[sum]>>number[sum];
        sum++;
        flag=1;
    }
    if(flag==1)
        sum--;
    myfile.close();
}
void kuncun::saveFile()
{
    QFile myfile(filename);
    myfile.open(QIODevice::Truncate);
    myfile.close();
    myfile.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&myfile);
    for(int i=0;i<sum+1;i++)
    {
        out<<name[i]<<" ";
        out<<number[i]<<endl;
    }
    myfile.close();
}
