#ifndef SALASPERSON_H
#define SALASPERSON_H

#include <QWidget>

namespace Ui {
class SalasPerson;
}

class SalasPerson : public QWidget
{
    Q_OBJECT

public:
    explicit SalasPerson(QWidget *parent = nullptr);
    ~SalasPerson();
    void paintEvent(QPaintEvent * event);

private slots:
    void on_pushButton_2_clicked();
    void on_pushButton_clicked();

private:
    Ui::SalasPerson *ui;
};

#endif // SALASPERSON_H
