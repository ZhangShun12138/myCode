#include "yginfor.h"
#include "QDebug"
#include "string"
#include "stdio.h"

YgInfor::YgInfor(const QString& str)
{
    filename=str;
    QFile myfile(str);
    sum=0;
    myfile.open(QIODevice::ReadOnly);
    QTextStream in(&myfile);
    int flag=0;
    while (!in.atEnd()) {
        in>>name[sum]>>number[sum]>>scshul[sum];
        sum++;
        flag=1;
    }
    if(flag!=0)
        sum--;
    myfile.close();
}
YgInfor::~YgInfor()
{

}

void YgInfor::saveFile()
{
    QFile myfile(filename);
    myfile.open(QIODevice::Truncate);
    myfile.close();
    myfile.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&myfile);string str=filename.toStdString();
    for(int i=0;i<=sum;i++)
    {
        out<<name[i]<<"    ";
        out<<number[i]<<"   ";
        out<<scshul[i]<<endl;
    }
    myfile.close();
}
