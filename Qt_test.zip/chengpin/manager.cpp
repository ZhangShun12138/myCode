#include "QString"
#include "manager.h"
#include "ui_manager.h"
#include "mainwindow.h"
#include "QMessageBox"
#include "managerwork.h"
#include "QPainter"
#include "QPaintEvent"

Manager::Manager(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Manager)
{
    ui->setupUi(this);
}

Manager::~Manager()
{
    delete ui;
}

void Manager::on_pushButton_2_clicked()
{
    MainWindow *a=new MainWindow;
    a->show();
    this->close();
}

void Manager::on_pushButton_clicked()
{
    QString Username=ui->lineEdit->text();
    QString Password=ui->lineEdit_2->text();

    if(Username!= "manager")
        QMessageBox::about(this,tr("Error!"),tr("用户名请输入manager"));
    else if(Password!="system")
        QMessageBox::about(this,tr("Error!"),tr("密码错误！"));
    else
    {
        managerwork * l=new managerwork;
        l->show();
        this->close();
    }
}


void Manager::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
