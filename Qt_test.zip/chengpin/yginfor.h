#ifndef YGINFOR_H
#define YGINFOR_H
#include "QString"
#include "QFile"
#include "QTextStream"
#include "QTableWidget"

using namespace std;

class YgInfor
{
public:
    YgInfor();
    QString filename;
    QString name[30];
    QString number[30];
    QString scshul[30];
    int sum;
    YgInfor(const QString& str);
    ~YgInfor();
    void saveFile();
};

#endif // YGINFOR_H
