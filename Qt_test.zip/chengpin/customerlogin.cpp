#include "customerlogin.h"
#include "ui_customerlogin.h"
#include "QMessageBox"
#include "mainwindow.h"
#include "QPainter"
#include "QPaintEvent"

customerlogin::customerlogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::customerlogin)
{
    ui->setupUi(this);
}

customerlogin::~customerlogin()
{
    delete ui;
}

void customerlogin::on_pushButton_clicked()
{
    QString user=ui->lineEdit->text();
    QString pass=ui->lineEdit_2->text();

    kuncun * temp=new kuncun("./file/yonghu.txt");

    for(int i=0;i<temp->sum;i++)
    {
        if(user!=temp->name[i])
            continue;
        else if(pass!=temp->number[i])
        {
            QMessageBox::about(this,"Error!","密码错误！");
            return;
        }
        else
        {
            customer * l=new customer;
            l->username=user;
            l->show();
            this->close();
            return;
        }
    }
    QMessageBox::about(this,"Error!","没有该用户！请点击注册！");

}

void customerlogin::on_pushButton_2_clicked()
{
    QString user=ui->lineEdit->text();
    QString pass=ui->lineEdit_2->text();

    if(user=="")
    {
        QMessageBox::about(this,"Error!","用户名不能为空!");
        return;
    }
    else if(pass=="")
    {
        QMessageBox::about(this,"Error!","密码不能为空!");
        return;
    }

    kuncun * temp=new kuncun("./file/yonghu.txt");

    for(int i=0;i<temp->sum;i++)
    {
        if(user!=temp->name)
            continue;
        else
        {
            QMessageBox::about(this,"Error!","该账号已经存在！");
            return;
        }
    }

    temp->name[temp->sum]=user;
    temp->number[temp->sum]=pass;
    temp->sum++;
    temp->saveFile();

}

void customerlogin::on_pushButton_3_clicked()
{
    MainWindow * l=new MainWindow();
    l->show();
    this->close();
}

void customerlogin::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
