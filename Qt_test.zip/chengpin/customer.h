#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <QWidget>
#include <QString>

namespace Ui {
class customer;
}

class customer : public QWidget
{
    Q_OBJECT

public:
    explicit customer(QWidget *parent = nullptr);
    ~customer();
    QString username;
    void paintEvent(QPaintEvent * event);

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::customer *ui;
};

#endif // CUSTOMER_H
