#include "ZsSaveFile.h"

void ZsaveFile(QString st,const QTableWidget * tab)
{
    int Rom=tab->rowCount();
    int Column=tab->columnCount();
    QFile myfile(st);
    myfile.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&myfile);;
    for(int i=0;i<Rom;i++)
    {
        for(int j=0;j<Column;j++)
            out<<tab->item(i,j)->text()<<"   ";
        out<<endl;
    }
    myfile.close();
}
