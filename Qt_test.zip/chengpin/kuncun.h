#ifndef KUNCUN_H
#define KUNCUN_H
#include "QString"
#include "QFile"
#include "QTextStream"

class kuncun
{
public:
    kuncun();
    QString filename;
    QString name[30];
    QString number[30];
    int sum;
    kuncun(const QString& str);
    ~kuncun();
    void saveFile();
};

#endif // KUNCUN_H
