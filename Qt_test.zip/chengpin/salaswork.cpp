#include "salaswork.h"
#include "ui_salaswork.h"
#include "salasperson.h"
#include "yginfor.h"
#include "kuncun.h"
#include "ZsSaveFile.h"
#include "QMessageBox"
#include "QPainter"
#include "QPaintEvent"

salaswork::salaswork(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::salaswork)
{
    ui->setupUi(this);
    kuncun * TempSql=new kuncun("./file/kucun.txt");
    ui->tableWidget->setRowCount(TempSql->sum);
    for (int i=0;i<TempSql->sum;i++)
    {
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(TempSql->name[i]));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(TempSql->number[i]));
    }
}

salaswork::~salaswork()
{
    delete ui;
}

void salaswork::on_pushButton_clicked()
{
    SalasPerson *l=new SalasPerson;
    l->show();
    this->close();
}

void salaswork::on_pushButton_2_clicked()
{
    int l=ui->spinBox->text().toInt();
    YgInfor ygTemp("./file/yuangong.txt");
    for(int i=0;i<=ygTemp.sum;i++)
    {
        if(Username==ygTemp.number[i])
            ygTemp.scshul[i]=QString::number(l+ygTemp.scshul->toInt());
    }
    ygTemp.saveFile();
    int x=ui->tableWidget->currentRow();
    int y=ui->tableWidget->currentColumn();

    if(y!=1)
    {
        QMessageBox::about(this,"Error!","请点击当前商品数量!");
        return;
    }

    int k=ui->tableWidget->item(x,y)->text().toInt();
    QString str=QString::number(k-l);
    ui->tableWidget->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/kucun.txt",ui->tableWidget);
}

void salaswork::on_pushButton_3_clicked()
{
    int x=ui->tableWidget->currentRow();
    int y=ui->tableWidget->currentColumn();
    if(y!=1)
    {
        QMessageBox::about(this,"Error!","请点击当前商品数量!");
        return;
    }
    int l=ui->spinBox_2->text().toInt();
    int k=ui->tableWidget->item(x,y)->text().toInt();
    QString str=QString::number(k+l);
    ui->tableWidget->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/kucun.txt",ui->tableWidget);
}

void salaswork::on_pushButton_4_clicked()
{
    kuncun * temp=new kuncun("./file/kucun.txt");

    QString name=ui->lineEdit->text();
    QString number=ui->lineEdit_2->text();

    if(name=="")
    {
        QMessageBox::about(this,"Error!","请输入商品名称!");
        return;
    }
    else if(number.toInt()<=0)
    {
        QMessageBox::about(this,"Error!","请输入正确数量!");
        return;
    }
    for(int i=0;i<=temp->sum;i++)
    {
        if(name==temp->name[i])
        {
            QMessageBox::about(this,"Error!","仓库中已有该物品!");
            return;
        }
    }

    int x=ui->tableWidget->rowCount();
    ui->tableWidget->setRowCount(x+1);
    ui->tableWidget->setItem(x,0,new QTableWidgetItem(name));
    ui->tableWidget->setItem(x,1,new QTableWidgetItem(number));

    ZsaveFile("./file/kucun.txt",ui->tableWidget);
}

void salaswork::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
