#ifndef CUSTOMERLOGIN_H
#define CUSTOMERLOGIN_H

#include <QWidget>
#include <QString>
#include <customer.h>
#include <ZsSaveFile.h>
#include <kuncun.h>

namespace Ui {
class customerlogin;
}

class customerlogin : public QWidget
{
    Q_OBJECT

public:
    explicit customerlogin(QWidget *parent = nullptr);
    ~customerlogin();
    void paintEvent(QPaintEvent * event);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::customerlogin *ui;
};

#endif // CUSTOMERLOGIN_H
