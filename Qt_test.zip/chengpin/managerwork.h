#ifndef MANAGERWORK_H
#define MANAGERWORK_H

#include <QWidget>
#include "yginfor.h"

namespace Ui {
class managerwork;
}

class managerwork : public QWidget
{
    Q_OBJECT

public:
    explicit managerwork(QWidget *parent = nullptr);
    ~managerwork();
    void paintEvent(QPaintEvent * event);

private slots:
    void on_pushButton_5_clicked();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_14_clicked();
    void on_pushButton_15_clicked();

private:
    Ui::managerwork *ui;
};

#endif // MANAGERWORK_H
