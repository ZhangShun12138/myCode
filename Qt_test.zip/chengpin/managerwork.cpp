#include "managerwork.h"
#include "ui_managerwork.h"
#include "manager.h"
#include "QTableWidget"
#include "yginfor.h"
#include "ZsSaveFile.h"
#include "QMessageBox"
#include "kuncun.h"
#include "QPainter"
#include "QPaintEvent"

managerwork::managerwork(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::managerwork)
{
    ui->setupUi(this);
    YgInfor * TempSql=new YgInfor("./file/yuangong.txt");
    ui->tableWidget->setRowCount(TempSql->sum);
    for (int i=0;i<TempSql->sum;i++)
    {
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(TempSql->name[i]));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(TempSql->number[i]));
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(TempSql->scshul[i]));
    }
    YgInfor * TempSql_2=new YgInfor("./file/shouhou.txt");
    ui->tableWidget_2->setRowCount(TempSql_2->sum);
    for (int i=0;i<TempSql_2->sum;i++)
    {
        ui->tableWidget_2->setItem(i,0,new QTableWidgetItem(TempSql_2->name[i]));
        ui->tableWidget_2->setItem(i,1,new QTableWidgetItem(TempSql_2->number[i]));
        ui->tableWidget_2->setItem(i,2,new QTableWidgetItem(TempSql_2->scshul[i]));
    }
}

managerwork::~managerwork()
{
    delete ui;
}

void managerwork::on_pushButton_5_clicked()
{
    Manager * a=new Manager;
    a->show();
    this->close();
}

void managerwork::on_pushButton_clicked()       //申请通过
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();
    if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_2_clicked()
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton_2->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_3_clicked()
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton_3->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_4_clicked()
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton_4->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_6_clicked()
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton_6->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_7_clicked()
{
    int x=ui->tableWidget_2->currentRow();
    int y=ui->tableWidget_2->currentColumn();if(y!=2)
    {
        QMessageBox::about(this,"Error!","请先点击当前状态");
        return;
    }
    QString str=ui->pushButton_7->text();
    ui->tableWidget_2->setItem(x,y,new QTableWidgetItem(str));
    ZsaveFile("./file/shouhou.txt",ui->tableWidget_2);
}

void managerwork::on_pushButton_14_clicked()
{
    int x=ui->tableWidget->currentRow();
    if(x!=-1)
        ui->tableWidget->removeRow(x);
    ZsaveFile("./file/yuangong.txt",ui->tableWidget);
}

void managerwork::on_pushButton_15_clicked()
{
    kuncun * temp=new kuncun("./file/dengluxx.txt");

    QString name=ui->lineEdit->text();
    QString number=ui->lineEdit_2->text();
    QString scshul="0";
    QString pass=ui->lineEdit_3->text();

    if(name=="")
    {
        QMessageBox::about(this,"Error!","请输入姓名！");
        return;
    }

    if(number=="")
    {
        QMessageBox::about(this,"Error!","请输入员工编号！");
        return;
    }

    for (int i=0;i<=temp->sum;i++)
    {
        if(temp->name[i]==number)
        {
            QMessageBox::about(this,"Error!","该员工编号以存在！");
            return;
        }
    }
    if(pass=="")
    {
        QMessageBox::about(this,"Error!","密码不能为空！");
        return;
    }
    unsigned int x=ui->tableWidget->rowCount();
    ui->tableWidget->setRowCount(x+1);
    ui->tableWidget->setItem(x,0,new QTableWidgetItem(name));
    ui->tableWidget->setItem(x,1,new QTableWidgetItem(number));
    ui->tableWidget->setItem(x,2,new QTableWidgetItem(scshul));
    ZsaveFile("./file/yuangong.txt",ui->tableWidget);

    temp->name[temp->sum]=number;
    temp->number[temp->sum]=pass;
    temp->sum++;
    temp->saveFile();
}

void managerwork::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
