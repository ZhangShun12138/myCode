#ifndef ZSSAVEFILE_H
#define ZSSAVEFILE_H

#include "QFile"
#include "QTableWidget"
#include "QString"
#include "QTextStream"

void ZsaveFile(QString st,const QTableWidget * tab);

#endif // ZSSAVEFILE_H
