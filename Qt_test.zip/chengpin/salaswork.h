#ifndef SALASWORK_H
#define SALASWORK_H

#include <QWidget>
#include <QLabel>
#include "kuncun.h"
#include "QFile"

namespace Ui {
class salaswork;
}

class salaswork : public QWidget
{
    Q_OBJECT

public:
    QString Username;
    explicit salaswork(QWidget *parent = nullptr);
    ~salaswork();
    QLabel * myLab;
    void paintEvent(QPaintEvent * event);

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();

private:
    Ui::salaswork *ui;
};

#endif // SALASWORK_H
