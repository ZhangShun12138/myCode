#include "salasperson.h"
#include "ui_salasperson.h"
#include "mainwindow.h"
#include "QString"
#include "QFile"
#include "QTextStream"
#include "QMessageBox"
#include "salaswork.h"
#include "QPainter"
#include "QPaintEvent"

SalasPerson::SalasPerson(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SalasPerson)
{
    ui->setupUi(this);
}

SalasPerson::~SalasPerson()
{
    delete ui;
}

void SalasPerson::on_pushButton_2_clicked()
{
    MainWindow *l=new MainWindow;
    l->show();
    this->close();
}

void SalasPerson::on_pushButton_clicked()
{
    QString Username=ui->lineEdit->text();
    QString Password=ui->lineEdit_2->text();

    QFile DeL(tr("./file/dengluxx.txt"));
    DeL.open(QIODevice::ReadOnly);
    QTextStream in(&DeL);
    QString TempUser;
    QString TempPass;
    while (!in.atEnd())
    {
        in>>TempUser>>TempPass;
        if(Username!=TempUser)
            continue;
        else if(Password!=TempPass)
        {
            QMessageBox::about(this,"Error!","密码错误！");
            DeL.close();
            return;
        }
        else
        {
            salaswork *l=new salaswork;
            l->show();
            l->Username=Username;
            this->close();
            DeL.close();
            return;
        }
    }
    DeL.close();
    QMessageBox::about(this,"Error!","没有此员工");
}


void SalasPerson::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
