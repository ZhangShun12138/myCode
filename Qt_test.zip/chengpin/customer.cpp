#include "customer.h"
#include "ui_customer.h"
#include "mainwindow.h"
#include "yginfor.h"
#include "QMessageBox"
#include "ZsSaveFile.h"
#include "customerlogin.h"
#include "QPainter"
#include "QPaintEvent"

customer::customer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::customer)
{
    ui->setupUi(this);
}

customer::~customer()
{
    delete ui;
}

void customer::on_pushButton_3_clicked()
{
    customerlogin * l=new customerlogin();
    l->show();
    this->close();
}

void customer::on_pushButton_clicked()
{
    YgInfor sql("./file/shouhou.txt");
    QString str=ui->lineEdit_2->text();

    if(str=="")
    {
        QMessageBox::about(this,"添加失败！","家电栏为空！");
        return;
    }

    QString st1=ui->comboBox->currentText();
    QMessageBox::about(this,"添加成功！","已添加，点击'查看维修情况查询'可查看维修情况！");
    sql.name[sql.sum]=username;
    sql.number[sql.sum]=str;
    sql.scshul[sql.sum]="待审核-"+st1;
    sql.sum++;
    sql.saveFile();
}

void customer::on_pushButton_2_clicked()
{
    YgInfor sql("./file/shouhou.txt");
    int flag=1;
    for(int i=0;i<=sql.sum;i++)
    {
        if(username==sql.name[i])
        {
            QMessageBox::about(this,"维修状态",sql.number[i]+" "+sql.scshul[i]);
            flag=0;
        }
    }
    if(flag==1)
        QMessageBox::about(this,"Error!","没有您的订单信息！");
}

void customer::paintEvent(QPaintEvent * event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}
